const canvas = document.getElementById("scene");
const gl = canvas.getContext("webgl");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Performans testine dair bilgiler
let cubes = [];
let frameCount = 0;
let fpsData = [];
let running = false;
let progressBar = document.getElementById("progressBar");

// K�p say�s�n�n test s�resi ve y�k� �zerindeki etkisi
let cpuLoad = 0;

// Performans testi i�in i�lemciyi zorlayacak fonksiyon
function startTest() {
    if (running) return;
    running = true;

    // Kullan�c�dan al�nan k�p say�s� ve test s�resi
    const cubeCount = document.getElementById("cubeCount").value;
    const duration = document.getElementById("testTime").value * 1000;

    createCubes(cubeCount);  // K�p say�s�na g�re k�pler olu�turuluyor

    const startTime = performance.now();
    frameCount = 0;
    fpsData = [];

    // Progress Bar'� s�f�rla
    progressBar.style.width = "0%";

    // Testi ba�lat�yoruz
    function render() {
        const currentTime = performance.now();
        const elapsedTime = currentTime - startTime;
        const progress = (elapsedTime / duration) * 100;

        // Progress bar'�n ilerlemesini ayarla
        progressBar.style.width = `${progress}%`;

        frameCount++;
        fpsData.push(1000 / (currentTime - startTime));

        // K�pleri �izme ve i�lemciyi zorlamaya devam etme
        drawCubes();

        // Cihaz�n y�k�n� art�r
        simulateDeviceLoad(cubeCount);

        if (elapsedTime < duration) {
            requestAnimationFrame(render);
        } else {
            calculateScore(cubeCount);  // Test bitiminde puan hesapla
            running = false;
        }
    }

    requestAnimationFrame(render);
}

// K�pleri �izme
function drawCubes() {
    // K�plerin her birinin d�n���n� burada yap�yoruz (3D �izim i�in WebGL kullan�labilir)
    cubes.forEach((cube) => {
        cube.rotation[0] += 0.01;
        cube.rotation[1] += 0.01;
        cube.rotation[2] += 0.01;
    });
}

// K�p olu�turma fonksiyonu
function createCubes(count) {
    cubes = [];
    for (let i = 0; i < count; i++) {
        cubes.push({
            position: [
                Math.random() * 20 - 10,
                Math.random() * 20 - 10,
                Math.random() * 20 - 10,
            ],
            rotation: [0, 0, 0],
        });
    }
}

// Cihaz�n i�lemcisini zorlamak (k�p say�s�na g�re y�k art�rma)
function simulateDeviceLoad(cubeCount) {
    cpuLoad = Math.min(cubeCount, 1024) * 0.01; // K�p say�s�na ba�l� i�lemci y�k�

    // CPU'yu zorlamak i�in d�ng� (buras� ger�ek bir CPU y�k� olu�turur)
    const startTime = performance.now();
    while (performance.now() - startTime < cpuLoad) {
        // Y�k� sim�le etmek i�in bo� d�ng�
    }
}

// Performans puan� hesaplama
function calculateScore(cubeCount) {
    const avgFps = fpsData.reduce((a, b) => a + b) / fpsData.length;
    let score = Math.round(avgFps * 1000);

    // K�p say�s�na g�re performans ve cihaz y�k�
    score = score * (1024 / cubeCount);  // K�p say�s� artt�k�a puan azal�r

    // Skoru ekran �zerinde g�ster
    document.getElementById("scoreDisplay").innerText = `Skor: ${Math.round(score)}`;
}

// Testi ba�latma butonuna t�klanmas�yla i�lemi ba�lat
document.getElementById("startButton").addEventListener("click", startTest);
