# Bootstrap List Grid View

A Pen created on CodePen.io. Original URL: [https://codepen.io/ajaypatelaj/pen/NWyPpZ](https://codepen.io/ajaypatelaj/pen/NWyPpZ).

Bootstrap List Grid View