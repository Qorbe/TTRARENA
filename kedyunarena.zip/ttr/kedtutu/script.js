document.getElementById('startTest').addEventListener('click', function () {
    const startButton = this;
    const resultDiv = document.getElementById('result');
    startButton.disabled = true;
    resultDiv.innerHTML = "Testing... Please wait.";

    let fps = 0;
    let startTime = performance.now();
    let frameCount = 0;

    function measureFPS() {
        frameCount++;
        const currentTime = performance.now();
        if (currentTime - startTime >= 1000) {
            fps = frameCount;
            calculatePerformance(fps);
        } else {
            requestAnimationFrame(measureFPS);
        }
    }

    function calculatePerformance(fps) {
        // Basit bir CPU testi (d�ng� ile i�lem yaparak cihaz� zorlar)
        const cpuStart = performance.now();
        for (let i = 0; i < 1e7; i++) { }
        const cpuEnd = performance.now();
        const cpuScore = Math.max(1000 - (cpuEnd - cpuStart), 0);

        // Genel performans puan� hesaplama
        const totalScore = Math.round(fps * 10 + cpuScore);
        resultDiv.innerHTML = `
      <p><strong>Test Complete!</strong></p>
      <p>FPS: ${fps}</p>
      <p>CPU Score: ${Math.round(cpuScore)}</p>
      <p><strong>Total Performance Score: ${totalScore}</strong></p>
    `;
        startButton.disabled = false;
    }

    requestAnimationFrame(measureFPS);
});
